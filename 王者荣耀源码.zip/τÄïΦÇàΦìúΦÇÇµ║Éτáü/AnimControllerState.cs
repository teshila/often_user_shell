using System;

public enum AnimControllerState
{
	Idle,
	Move,
	Attack,
	Skill,
	Death,
	Other
}
