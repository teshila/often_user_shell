using System;

public enum AkActionOnEventType
{
	AkActionOnEventType_Stop,
	AkActionOnEventType_Pause,
	AkActionOnEventType_Resume,
	AkActionOnEventType_Break,
	AkActionOnEventType_ReleaseEnvelope
}
