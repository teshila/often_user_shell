using System;

namespace Assets.MobaTools.TriggerPlugin.Scripts
{
	public enum EEventID2_navigation
	{
		eOnStopPath = 1
	}
}
