using System;

namespace Assets.MobaTools.TriggerPlugin.Scripts
{
	public class TriggerEvent2_navigation : TriggerEvent2
	{
		public TriggerEvent2_navigation(ITriggerCreatorParam param) : base(param)
		{
		}
	}
}
