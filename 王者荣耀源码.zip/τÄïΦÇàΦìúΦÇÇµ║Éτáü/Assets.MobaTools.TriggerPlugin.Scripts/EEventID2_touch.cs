using System;

namespace Assets.MobaTools.TriggerPlugin.Scripts
{
	public enum EEventID2_touch
	{
		eDown = 1,
		ePress,
		eUp,
		eMoveEnd
	}
}
