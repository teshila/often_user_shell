using System;

namespace Assets.MobaTools.TriggerPlugin.Scripts
{
	public enum ETriggerType2
	{
		TriggerEvent2_manulController = 1,
		TriggerEvent2_skillControl,
		TriggerEvent2_navigation
	}
}
