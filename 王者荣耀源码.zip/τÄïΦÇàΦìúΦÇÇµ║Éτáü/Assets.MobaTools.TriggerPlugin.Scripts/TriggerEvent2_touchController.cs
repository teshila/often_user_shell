using System;

namespace Assets.MobaTools.TriggerPlugin.Scripts
{
	internal class TriggerEvent2_touchController : TriggerEvent2
	{
		public TriggerEvent2_touchController(ITriggerCreatorParam param) : base(param)
		{
		}
	}
}
