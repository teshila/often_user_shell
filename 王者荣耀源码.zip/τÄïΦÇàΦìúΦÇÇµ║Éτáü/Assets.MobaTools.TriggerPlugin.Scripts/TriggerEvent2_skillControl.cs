using System;

namespace Assets.MobaTools.TriggerPlugin.Scripts
{
	public class TriggerEvent2_skillControl : TriggerEvent2
	{
		public TriggerEvent2_skillControl(ITriggerCreatorParam param) : base(param)
		{
		}
	}
}
