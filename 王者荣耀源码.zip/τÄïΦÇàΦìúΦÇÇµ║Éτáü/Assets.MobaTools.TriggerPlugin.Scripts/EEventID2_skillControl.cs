using System;

namespace Assets.MobaTools.TriggerPlugin.Scripts
{
	public enum EEventID2_skillControl
	{
		ePressSkill = 1,
		eKillEnd
	}
}
