using System;

namespace Assets.MobaTools.TriggerPlugin.Scripts
{
	internal class TriggerEvent2_manulController : TriggerEvent2
	{
		public TriggerEvent2_manulController(ITriggerCreatorParam param) : base(param)
		{
		}
	}
}
