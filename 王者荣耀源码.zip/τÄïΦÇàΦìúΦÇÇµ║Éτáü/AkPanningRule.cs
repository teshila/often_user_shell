using System;

public enum AkPanningRule
{
	AkPanningRule_Speakers,
	AkPanningRule_Headphones
}
