using System;

public enum AkAudioAPI
{
	AkAPI_Default = 1,
	AkAPI_Dummy = 4
}
