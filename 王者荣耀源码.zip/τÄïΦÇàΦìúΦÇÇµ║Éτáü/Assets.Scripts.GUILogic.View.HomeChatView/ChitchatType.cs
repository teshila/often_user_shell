using System;

namespace Assets.Scripts.GUILogic.View.HomeChatView
{
	public enum ChitchatType
	{
		None,
		Hall,
		Friend,
		Lobby
	}
}
