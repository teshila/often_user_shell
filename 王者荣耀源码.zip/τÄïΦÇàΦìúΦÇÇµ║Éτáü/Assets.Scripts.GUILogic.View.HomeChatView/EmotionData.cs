using System;

namespace Assets.Scripts.GUILogic.View.HomeChatView
{
	public struct EmotionData
	{
		public string serialNumber;

		public string strContent;

		public int position;

		public int row;

		public int totalConSpace;

		public float totalNonSpace;
	}
}
