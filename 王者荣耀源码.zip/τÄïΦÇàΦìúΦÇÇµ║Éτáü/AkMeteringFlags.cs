using System;

public enum AkMeteringFlags
{
	AK_NoMetering,
	AK_EnableBusMeter_Peak,
	AK_EnableBusMeter_TruePeak,
	AK_EnableBusMeter_RMS = 4,
	AK_EnableBusMeter_KPower = 16
}
