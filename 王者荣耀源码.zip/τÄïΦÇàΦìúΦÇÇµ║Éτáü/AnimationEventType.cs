using System;

public enum AnimationEventType
{
	Idle = 1,
	Move,
	Run,
	Attack,
	Conjure,
	Hit,
	Death
}
