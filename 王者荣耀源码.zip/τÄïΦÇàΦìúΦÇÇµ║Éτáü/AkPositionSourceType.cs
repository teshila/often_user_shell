using System;

public enum AkPositionSourceType
{
	AkUserDef,
	AkGameDef
}
