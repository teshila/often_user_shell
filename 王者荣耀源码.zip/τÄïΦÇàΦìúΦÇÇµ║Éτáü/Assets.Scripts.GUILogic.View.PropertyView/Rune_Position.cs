using System;

namespace Assets.Scripts.GUILogic.View.PropertyView
{
	public enum Rune_Position
	{
		None,
		Level1,
		Level5,
		Level10,
		Level15,
		Level20,
		Level30
	}
}
