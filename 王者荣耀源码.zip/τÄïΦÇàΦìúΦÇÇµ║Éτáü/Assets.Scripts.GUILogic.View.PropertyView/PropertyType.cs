using System;

namespace Assets.Scripts.GUILogic.View.PropertyView
{
	public enum PropertyType
	{
		Info,
		Skill,
		Nature,
		Collection,
		Rune,
		Other
	}
}
