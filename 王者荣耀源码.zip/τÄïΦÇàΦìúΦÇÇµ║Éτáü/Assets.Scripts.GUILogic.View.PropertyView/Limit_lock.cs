using System;

namespace Assets.Scripts.GUILogic.View.PropertyView
{
	public enum Limit_lock
	{
		locked,
		unlocked
	}
}
