using System;

namespace Assets.Scripts.GUILogic.View.PropertyView
{
	public enum RunesClassification
	{
		All,
		Primary,
		Middle,
		High,
		Super,
		Top
	}
}
