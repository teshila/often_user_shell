using System;

namespace Assets.Scripts.GUILogic.View.PropertyView
{
	public enum SkillIndex
	{
		None,
		_1st,
		_2nd,
		_3rd,
		_4th
	}
}
