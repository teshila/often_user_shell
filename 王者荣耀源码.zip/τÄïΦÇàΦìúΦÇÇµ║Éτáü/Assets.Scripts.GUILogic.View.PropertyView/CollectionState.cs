using System;

namespace Assets.Scripts.GUILogic.View.PropertyView
{
	public enum CollectionState
	{
		Nothing,
		Sending
	}
}
