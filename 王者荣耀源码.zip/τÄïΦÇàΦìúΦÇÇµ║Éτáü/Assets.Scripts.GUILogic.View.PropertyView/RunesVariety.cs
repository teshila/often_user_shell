using System;

namespace Assets.Scripts.GUILogic.View.PropertyView
{
	public enum RunesVariety
	{
		All,
		Attack,
		Spell,
		Survive
	}
}
