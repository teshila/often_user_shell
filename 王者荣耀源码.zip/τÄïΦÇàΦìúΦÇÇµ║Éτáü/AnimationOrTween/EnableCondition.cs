using System;

namespace AnimationOrTween
{
	public enum EnableCondition
	{
		DoNothing,
		EnableThenPlay
	}
}
