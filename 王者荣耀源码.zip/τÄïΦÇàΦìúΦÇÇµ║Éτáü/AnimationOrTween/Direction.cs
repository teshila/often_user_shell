using System;

namespace AnimationOrTween
{
	public enum Direction
	{
		Reverse = -1,
		Toggle,
		Forward
	}
}
