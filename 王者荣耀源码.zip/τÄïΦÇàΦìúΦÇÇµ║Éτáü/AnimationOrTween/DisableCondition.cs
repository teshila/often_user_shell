using System;

namespace AnimationOrTween
{
	public enum DisableCondition
	{
		DisableAfterReverse = -1,
		DoNotDisable,
		DisableAfterForward
	}
}
