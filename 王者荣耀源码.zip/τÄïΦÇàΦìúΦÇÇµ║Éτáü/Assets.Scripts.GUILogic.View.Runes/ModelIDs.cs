using System;

namespace Assets.Scripts.GUILogic.View.Runes
{
	public struct ModelIDs
	{
		public int modelID_1;

		public int modelID_2;

		public int modelID_3;
	}
}
