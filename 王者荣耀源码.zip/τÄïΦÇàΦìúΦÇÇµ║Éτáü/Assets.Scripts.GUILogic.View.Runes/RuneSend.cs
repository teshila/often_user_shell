using System;

namespace Assets.Scripts.GUILogic.View.Runes
{
	public struct RuneSend
	{
		public int ModelID;

		public int Count1;

		public int Count2;
	}
}
