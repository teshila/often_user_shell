using System;

namespace Assets.Scripts.GUILogic.View.Runes
{
	public struct RunesOperaInfo
	{
		public string equipID;

		public string modelID;

		public int runesPosition;
	}
}
