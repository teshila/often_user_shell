using System;

namespace Assets.Scripts.GUILogic.View.Runes
{
	public enum RunesFunctionType
	{
		None,
		Inlay,
		Storage
	}
}
