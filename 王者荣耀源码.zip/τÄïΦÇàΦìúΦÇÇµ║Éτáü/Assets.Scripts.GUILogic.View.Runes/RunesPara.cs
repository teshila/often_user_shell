using Assets.Scripts.GUILogic.View.PropertyView;
using System;

namespace Assets.Scripts.GUILogic.View.Runes
{
	public struct RunesPara
	{
		public bool isNeedRefresh;

		public RunesItem runesItem;
	}
}
