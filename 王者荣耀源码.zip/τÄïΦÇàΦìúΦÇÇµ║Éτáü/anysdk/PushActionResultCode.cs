using System;

namespace anysdk
{
	public enum PushActionResultCode
	{
		kPushReceiveMessage,
		kPushExtensionCode = 60000
	}
}
