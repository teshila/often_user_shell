using System;

namespace anysdk
{
	public enum AccountGender
	{
		MALE,
		FEMALE,
		UNKNOWN
	}
}
