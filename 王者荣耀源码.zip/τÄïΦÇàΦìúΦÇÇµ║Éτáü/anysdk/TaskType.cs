using System;

namespace anysdk
{
	public enum TaskType
	{
		GUIDE_LINE,
		MAIN_LINE,
		BRANCH_LINE,
		DAILY,
		ACTIVITY,
		OTHER
	}
}
