using System;

namespace anysdk
{
	public enum AccountOperate
	{
		LOGIN,
		LOGOUT,
		REGISTER
	}
}
