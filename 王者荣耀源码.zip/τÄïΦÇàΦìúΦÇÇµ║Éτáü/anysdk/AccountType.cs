using System;

namespace anysdk
{
	public enum AccountType
	{
		ANONYMOUS,
		REGISTED,
		SINA_WEIBO,
		TENCENT_WEIBO,
		QQ,
		ND91
	}
}
