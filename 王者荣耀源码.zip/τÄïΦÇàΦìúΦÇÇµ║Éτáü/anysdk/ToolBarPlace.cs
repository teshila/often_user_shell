using System;

namespace anysdk
{
	public enum ToolBarPlace
	{
		kToolBarTopLeft = 1,
		kToolBarTopRight,
		kToolBarMidLeft,
		kToolBarMidRight,
		kToolBarBottomLeft,
		kToolBarBottomRight
	}
}
