using System;

namespace anysdk
{
	public enum AdsPos
	{
		kPosCenter,
		kPosTop,
		kPosTopLeft,
		kPosTopRight,
		kPosBottom,
		kPosBottomLeft,
		kPosBottomRight
	}
}
