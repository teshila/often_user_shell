using System;

namespace anysdk
{
	public enum CustomResultCode
	{
		kCustomExtension = 80000
	}
}
