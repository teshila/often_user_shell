using System;

namespace anysdk
{
	public enum RequestResultCode
	{
		kRequestSuccess = 31000,
		kRequestFail
	}
}
