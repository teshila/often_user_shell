using System;

namespace Assets.Scripts.Character.Control
{
	public class ManualControlSignal
	{
	}
}
