using System;

namespace Assets.Scripts.Character.Control
{
	public enum TouchEventType
	{
		down,
		press,
		up,
		moveEnd
	}
}
