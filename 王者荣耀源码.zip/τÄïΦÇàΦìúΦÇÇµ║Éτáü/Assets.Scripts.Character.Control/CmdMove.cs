using System;

namespace Assets.Scripts.Character.Control
{
	public class CmdMove : CmdBase
	{
		public CmdMove()
		{
			this.isMoveCmd = true;
		}
	}
}
