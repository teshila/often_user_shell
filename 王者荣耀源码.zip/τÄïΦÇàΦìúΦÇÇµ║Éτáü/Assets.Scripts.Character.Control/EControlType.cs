using System;

namespace Assets.Scripts.Character.Control
{
	public enum EControlType
	{
		eNull,
		eDown,
		ePress,
		eUp,
		eMoveEnd
	}
}
