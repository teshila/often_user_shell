using System;
using UnityEngine;

namespace Assets.Scripts.Character.Control
{
	public class CmdBase
	{
		public bool isMoveCmd;

		public bool isSkillCmd;

		public Vector3 targetPos;
	}
}
