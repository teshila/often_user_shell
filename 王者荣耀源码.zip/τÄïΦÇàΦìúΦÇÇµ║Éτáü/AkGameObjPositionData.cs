using System;
using UnityEngine;

public class AkGameObjPositionData
{
	public Vector3 position;

	public Vector3 forward;
}
