using System;

public enum ActionEvent
{
	ExitGame
}
