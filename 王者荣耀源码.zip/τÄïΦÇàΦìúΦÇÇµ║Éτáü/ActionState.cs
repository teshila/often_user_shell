using System;

public enum ActionState
{
	NONE,
	ACTION_INIT,
	ACTION_START,
	ACTION_END
}
