using System;

namespace Assets.Scripts.GUILogic.View.BottleSystemView
{
	public enum LackState
	{
		None,
		lackLegend,
		lackCollect
	}
}
