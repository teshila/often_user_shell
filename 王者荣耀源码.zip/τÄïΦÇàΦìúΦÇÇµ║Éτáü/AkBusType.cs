using System;

public enum AkBusType
{
	AkBusType_Master = 1,
	AkBusType_Primary
}
