using System;

public enum AkPannerType
{
	Ak2D,
	Ak3D
}
