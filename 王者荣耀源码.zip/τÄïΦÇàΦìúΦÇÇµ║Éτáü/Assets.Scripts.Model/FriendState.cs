using System;

namespace Assets.Scripts.Model
{
	public class FriendState
	{
		public byte opertype;

		public long targetSummid;
	}
}
