using MobaProtocol.Data;
using System;
using System.Collections.Generic;

namespace Assets.Scripts.Model
{
	public class MyRankList
	{
		public List<CharmRankData> CharmRankList;
	}
}
