using System;

namespace Assets.Scripts.Model
{
	public enum EBattleShopState
	{
		eIdle,
		eBuying,
		eSelling,
		eRollBack
	}
}
