using MobaProtocol.Data;
using System;
using System.Collections.Generic;

namespace Assets.Scripts.Model
{
	public class SummonerLadderData
	{
		public List<SummonerLadderRankData> rankList;

		public MatchTimeData matchTimeData;
	}
}
