using System;

namespace Assets.Scripts.Model
{
	public enum EBattleShopOP
	{
		eOpen,
		eClose,
		eBuy,
		eSell,
		eRevert
	}
}
