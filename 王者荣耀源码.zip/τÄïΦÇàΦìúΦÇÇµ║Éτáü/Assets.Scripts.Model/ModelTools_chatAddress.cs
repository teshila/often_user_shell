using System;

namespace Assets.Scripts.Model
{
	public static class ModelTools_chatAddress
	{
	}
}
