using System;

namespace Assets.Scripts.Model
{
	public class TimeClass
	{
		public DateTime ArenaTimeSpan = default(DateTime);
	}
}
