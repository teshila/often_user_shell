using System;

namespace Assets.Scripts.Model
{
	public enum EBattleShopContex
	{
		eNone,
		ePvp,
		ePve,
		eBrawl
	}
}
