using System;

namespace Assets.Scripts.Model
{
	public enum EBattleShopOpenType
	{
		eFromModel,
		eFromButton
	}
}
