using MobaProtocol.Data;
using System;
using System.Collections.Generic;

namespace Assets.Scripts.Model
{
	public class ChatMessageData
	{
		public ChatMessage chatMessage = new ChatMessage();

		public List<ChatMessage> CahtMessageList = new List<ChatMessage>();
	}
}
