using System;

namespace Assets.Scripts.Model
{
	public class SignState
	{
		public DateTime dataReceiveTime = default(DateTime);

		public int isPass = 1;

		public int week;
	}
}
