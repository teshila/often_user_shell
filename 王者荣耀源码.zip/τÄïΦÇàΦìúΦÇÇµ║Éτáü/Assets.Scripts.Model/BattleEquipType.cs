using System;

namespace Assets.Scripts.Model
{
	public enum BattleEquipType
	{
		all,
		attack,
		magic,
		defense,
		assist,
		recommend = 6,
		none
	}
}
