using MobaProtocol.Data;
using System;
using System.Collections.Generic;

namespace Assets.Scripts.Model
{
	public class AccountModelData
	{
		public AccountData accountData = new AccountData();

		public List<string[]> loginDataList = new List<string[]>();
	}
}
