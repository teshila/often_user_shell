using System;

namespace Assets.Scripts.Model
{
	public enum EBattleShopType
	{
		eNone,
		eLM,
		eBL,
		eNeutral,
		eTeam3,
		eNeutral_2
	}
}
