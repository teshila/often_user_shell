using System;

namespace Assets.Scripts.Model
{
	public class ModelVersionInfo
	{
		public string versionStr;
	}
}
