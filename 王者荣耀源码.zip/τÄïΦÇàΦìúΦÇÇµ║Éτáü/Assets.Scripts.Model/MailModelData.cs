using MobaProtocol.Data;
using System;
using System.Collections.Generic;

namespace Assets.Scripts.Model
{
	public class MailModelData
	{
		public List<MailData> mailList;

		public long modifyMailId;
	}
}
