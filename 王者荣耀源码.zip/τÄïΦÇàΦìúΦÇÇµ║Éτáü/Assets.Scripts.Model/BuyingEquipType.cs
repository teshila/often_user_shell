using System;

namespace Assets.Scripts.Model
{
	public enum BuyingEquipType
	{
		eNone,
		eRecommend,
		eShop,
		eMax
	}
}
