using System;

namespace Assets.Scripts.Model
{
	public enum BarrageSceneType
	{
		SelectHero = 1,
		BattleIn,
		WatcherMode,
		WatcherMode_SelectHero
	}
}
