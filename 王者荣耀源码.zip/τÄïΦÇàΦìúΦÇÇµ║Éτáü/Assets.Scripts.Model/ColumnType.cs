using System;

namespace Assets.Scripts.Model
{
	public enum ColumnType
	{
		one = 1,
		two,
		three
	}
}
