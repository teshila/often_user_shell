using System;

public enum AttackType
{
	Melee = 1,
	Remote
}
