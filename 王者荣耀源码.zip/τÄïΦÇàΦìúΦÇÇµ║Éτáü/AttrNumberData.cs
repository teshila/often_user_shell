using MobaHeros;
using System;

public class AttrNumberData
{
	public AttrType m_attrType;

	public float m_fMaxValue = 10000f;

	public float m_fMinValue;
}
