using System;

public enum AkNodeType
{
	AkNodeType_Default,
	AkNodeType_Bus
}
