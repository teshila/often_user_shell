using System;

public class Attack_Tulun : Skill
{
	public Attack_Tulun()
	{
	}

	public Attack_Tulun(string skill_id, Units self) : base(skill_id, self)
	{
	}
}
