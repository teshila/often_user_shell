using System;

public enum AkChannelOrdering
{
	ChannelOrdering_Standard,
	ChannelOrdering_RunTime
}
