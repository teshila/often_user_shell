using System;

public enum AkGroupType
{
	AkGroupType_Switch,
	AkGroupType_State
}
