using System;

public enum AkChannelConfigType
{
	AK_ChannelConfigType_Anonymous,
	AK_ChannelConfigType_Standard,
	AK_ChannelConfigType_Ambisonic
}
