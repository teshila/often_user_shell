using System;

public enum AkBankContent
{
	AkBankContent_StructureOnly,
	AkBankContent_All
}
