using System;

[Serializable]
public class ArrayIndexes
{
	public int[] indexes;
}
