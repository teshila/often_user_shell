using System;
using System.Collections.Generic;

public class AkGameObjEnvironmentData
{
	public List<AkEnvironment> activeEnvironments = new List<AkEnvironment>();

	public List<AkEnvironmentPortal> activePortals = new List<AkEnvironmentPortal>();

	public AkAuxSendArray auxSendValues;
}
