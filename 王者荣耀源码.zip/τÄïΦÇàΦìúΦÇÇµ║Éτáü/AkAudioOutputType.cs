using System;

public enum AkAudioOutputType
{
	AkOutput_Dummy = 4,
	AkOutput_MergeToMain = 8,
	AkOutput_Main = 16,
	AkOutput_NumOutputs = 32
}
