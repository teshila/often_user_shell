using System;

public enum AkConnectionType
{
	ConnectionType_Direct,
	ConnectionType_GameDefSend,
	ConnectionType_UserDefSend,
	ConnectionType_CrossDeviceSend = 4
}
